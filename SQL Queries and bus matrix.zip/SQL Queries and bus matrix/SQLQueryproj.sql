CREATE TABLE dim_customer (
    customer_id INT PRIMARY KEY,            
    Fullname VARCHAR(100),                
    phone_number VARCHAR(50),               
    gender VARCHAR(10),                     
    date_of_birth DATE,                     
    segmentation_id INT,                    
    segment_name VARCHAR(100),            
    description TEXT      
);


CREATE TABLE dim_agent (
    agent_id INT PRIMARY KEY,
    agent_name VARCHAR(100),
    department VARCHAR(100)
);

CREATE TABLE dim_time (
    time_id INT PRIMARY KEY,
    month INT,
    year INT
);

CREATE TABLE dim_location (
    location_id INT PRIMARY KEY,
    city VARCHAR(100),
    country VARCHAR(100)
);
CREATE TABLE feedback_summary (
    feedback_id INT PRIMARY KEY,
    customer_id INT,
    agent_id INT,
    feedback_text TEXT,
    suggestion_text TEXT,
    points_earned INT,
    interaction_type VARCHAR(100),
    interaction_date DATE,
    suggestion_date DATE,
    feedback_date DATE,
    location_id INT,
    time_id INT,
    FOREIGN KEY (customer_id) REFERENCES dim_customer(customer_id),
    FOREIGN KEY (agent_id) REFERENCES dim_agent(agent_id),
    FOREIGN KEY (location_id) REFERENCES dim_location(location_id),
    FOREIGN KEY (time_id) REFERENCES dim_time(time_id)
);

